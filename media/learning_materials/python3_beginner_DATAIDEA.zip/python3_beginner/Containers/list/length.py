# by Juma Shafara
# Python Collections: lists, length

pets = ['dog', 'cat', 'rabbit']

print(len(pets))