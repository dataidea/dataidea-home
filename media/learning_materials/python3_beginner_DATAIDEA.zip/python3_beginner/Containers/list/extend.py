# by Juma Shafara
# Python Collections: lists, extend

pets = ['dog', 'cat']
other_pets = ['rabbit', 'fish', 'hamster']

pets.extend(other_pets)

print(pets)