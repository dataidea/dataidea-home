# by Juma Shafara
# Python Collections: lists, adding items

pets = ['dog', 'cat', 'rabbit']

pets.append('fish') # append

pets.insert(2, 'hamster')

print(pets)

