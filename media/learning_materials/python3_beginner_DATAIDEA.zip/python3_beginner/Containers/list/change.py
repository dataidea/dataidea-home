# by Juma Shafara
# Python Collections: lists, length

pets = ['dog', 'cat', 'rabbit']

pets[1] = 'fish'

print(pets)