# by Juma Shafara
# Python Collections: lists, indexing

pets = ['dog', 'cat', 'rabbit']
print(pets[2])


