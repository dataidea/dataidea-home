# by Juma Shafara
# Python Collections: lists, loop

other_pets = ['rabbit', 'fish', 'hamster']

for pet in other_pets:
    print(pet)
