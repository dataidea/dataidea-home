# by Juma Shafara
# Python Collections: lists, adding items

pets = ['dog', 'cat', 'rabbit']

pets.pop()

pets.remove('cat')

del pets[0]

print(pets)

