# by Juma Shafara
# Python Collections: lists, extend

pets = list(('dog', 'cat', 'fish'))

# print(pets)

print(type(pets))