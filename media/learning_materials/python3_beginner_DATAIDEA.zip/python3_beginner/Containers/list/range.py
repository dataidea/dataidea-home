# by Juma Shafara
# Python Collections: lists, indexing, range

pets = ['dog', 'cat', 'rabbit', 'fish']

print(pets[2:])