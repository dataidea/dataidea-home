# by Juma Shafara
# Python Collections: lists, check

pets = ['dog', 'cat', 'rabbit']

print('fish' in pets)