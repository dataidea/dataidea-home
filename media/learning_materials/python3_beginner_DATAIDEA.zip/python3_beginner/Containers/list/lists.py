# by Juma Shafara
# Python Collections: lists

pets = ['dog', 'cat', 'rabbit']
print(pets)

mixed = ['dog', 21, True]

print(mixed)