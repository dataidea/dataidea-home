pets = ('dog', 'cat', 'rabbit')

