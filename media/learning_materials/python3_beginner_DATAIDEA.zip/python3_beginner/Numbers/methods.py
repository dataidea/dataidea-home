# By Juma Shafara

# Python Numbers: methods

# round off
# print(round(number=3.1415, ndigits=2))

# raise to a power
# print(pow(base=4, exp=2))

# get absolute value
# print(abs(-3.21))

# get quotient and reminder
# print(divmod(5, 2))

quo, rem = divmod(5, 2)

print(rem)

