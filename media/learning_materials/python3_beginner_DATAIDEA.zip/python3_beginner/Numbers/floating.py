# By Juma Shafara

# Python Numbers: floating point
a = 3.0
b = 4.21
number = 5.33
c = 6.123