# By Juma Shafara

# Python Numbers: complex

b = 4.21j
c = 3 + 5j

print(type(b))
