# By Juma Shafara

# Python Numbers: intgers

a = 3
b = 4
number = 5
c = 21