
# By Juma Shafara

# Python Numbers: type

a = 3
b = 5.21
c = 5.33j

print(type(a))
print(type(b))
print(type(c))