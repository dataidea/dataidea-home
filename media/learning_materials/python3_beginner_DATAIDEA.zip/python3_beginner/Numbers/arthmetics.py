# By Juma Shafara

# Python Numbers: arthmetics

summation = 4 + 2
print('sum:', summation)

difference = 4 - 2
print('difference:', difference)

product = 4 * 2
print('product:', product)

quotient = 4 / 2
print('quotient:', quotient)