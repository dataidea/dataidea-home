### Softwares
- Python Interpreter
- Visual Studio Code
- Jupyter Notebooks (lab)

### VSCode Extensions
- Python (Microsoft)
- Code Runner
- Jupyter (Microsoft)
- Prettier (Prettier)
