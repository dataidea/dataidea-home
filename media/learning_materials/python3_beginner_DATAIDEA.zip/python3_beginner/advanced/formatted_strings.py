# statement = '{} loves to code in {}'

# formatted = statement.format('Juma', 'JavaScript')

# print(formatted)

# name = 'Juma'; language = 'JavaScript'

# statement = f'{name} loves to code in {language}'

# print(statement)

# answer = f'The summation of 5 and 7 is {5 + 7}'

# print(answer)

# weight_kg = int(input('Enter your weight in kgs: '))
# height_m = float(input('Enter your height in m: '))

# response = f'Your weight is {"Normal" if 18 >= weight_kg / height_m ** 2 >= 24 else "Not Normal"}'

# print(response)

# Using indexes

name = 'Juma'
language = 'javascript'

statement = f'{name} loves to code in {language}'

# modified = statement.format(language='JavaScript', name='Juma')

print(statement)