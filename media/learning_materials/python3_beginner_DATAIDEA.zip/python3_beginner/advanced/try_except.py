# # try:
# #     statements
# # except:
# #     statements
# def dataideaArithmetic(x, y, operation):
#     if operation == '+':
#         return x + y
#     elif operation == '-':
#         return x - y
#     elif operation == '/':
#         return x / y 
#     else:
#         return x * y
    

# print('''
#     DATAIDEA Arithmects:
      
# Instructions
# -------------------------
# Enter only two numbers and the operation as +, -, /, x
# ''')


# number1 = float(input('Enter first number: '))
# number2 = float(input('Enter second number: '))
# operator = input('Enter the operator: ')


# try:
#     answer = dataideaArithmetic(number1, number2, operator)
#     print(f'{number1}{operator}{number2} = {answer}')
# except:
#     print('A problem occured while running the operation')
# else:
#     print('Your code has run successfully!')
# finally:
#     print('Code execution complete.')

# try:
#     age = input('Enter your age: ')
#     age_integer = int(age)

#     if age_integer >= 18:
#         print('Your vote has been cast')
#     else:
#         print('You are not eligible to vote')
# except ValueError:
#     print('A problem occured while picking your age \n'
#           'You did not enter a number')
# else:
#     print('Thanks for participating!')

# Creating your own errors

try: 
    age = int(input('Enter your age: '))

    if age < 18:
        raise Exception('Not an adult')
except Exception as error:
    print('A problem occurred \n'
          f'Error: {error}')
