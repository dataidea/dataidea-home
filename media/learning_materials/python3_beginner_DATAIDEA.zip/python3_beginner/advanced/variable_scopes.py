# number = 45 # defined outside a function

# # can be accessed here
# print(number)

# def getSquare():
#     # can also be accessed here
#     print(number ** 2)

# getSquare()

# Local Scope

# def add():
#     number1 = 5
#     number2 = 7
#     sum = number1 + number2
#     return sum

# # print(add())
# print(sum)


# Global Keyword

def add():
    global summ
    number1 = 5
    number2 = 7
    summ = number1 + number2
    return summ

add()

print(summ)