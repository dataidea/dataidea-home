# python numbers
# Integers
age = 45
population = 45000000

# Floating point numbers
height = 1.7
weight = 147.45

# complex numbers
cat = 4j
cat2 = 3 + 5j


# Strings
name = 'Juma'
other_name = "Masaba Calvin"
statement = 'I love coding'

# when to use which quotes
report = 'He said, "I will not go home"'

# Boolean
married = True

# Lists
names = ['juma', 'john', 'calvin']
other_stuff = ['mango', True, 38]

# Which data type
type(names)

