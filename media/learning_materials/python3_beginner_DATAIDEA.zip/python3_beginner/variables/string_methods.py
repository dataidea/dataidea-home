text = 'shafara VEe'
capitalized_text = text.capitalize()
# print(capitalized_text) 

upper_text = text.upper()
# print(upper_text)

lower_text = text.lower()
# print(lower_text)

corrected_text = text.replace('VEe', 'Viola')
# print(corrected_text)

print('shafara' not in text)