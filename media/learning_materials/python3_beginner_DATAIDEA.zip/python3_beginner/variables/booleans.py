isCute = True
print(type(isCute))