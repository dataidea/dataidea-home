# convert an integer to a string
age = 45
message = 'Peter Griffin is '+ str(age) + ' years old'

# Convert floating point to integer
pi = 3.14159
print(int(pi))

