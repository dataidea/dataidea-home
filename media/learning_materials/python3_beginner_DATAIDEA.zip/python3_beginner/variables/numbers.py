# integers
a = 3
b = 4
c = 5

# floating points
d = 3.0
e = 4.21
f = 5.33

# complex numbers
g = 3j
h = 4.21j
i = 1 + 2j

# Finding data type
# print(type(a))

# adding numbers
sum = 4 + 2

# subtract numbers
difference = 4 - 2

# multiply numbers
product = 4 * 2

# divide numbers
quotient = 4 / 2


average = (1 + 3 + 4 +7) / 4
print(average)