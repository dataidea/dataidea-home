fruit = 'mango'
name = 'voila'

print(name, ' likes ', fruit )

# Rules to consider 
# 1. Spaces are not allowed eg 
# 2. Can not start with number eg
# 3. Can not have special characters eg
# 4. Are case sensitive

my_favorite_character = 'Stewie Griffin' # snake case
myFavoriteCharacter = 'Meg Griffin' # camel case
MyFavoriteCharacter = 'Brian Griffin' # Pascal case