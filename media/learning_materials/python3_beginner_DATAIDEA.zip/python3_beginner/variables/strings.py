# Strings
name = 'Juma'
other_name = "Masaba"
statement = 'I love coding'

# adding strings (appending strings)
full_name = name + other_name
full_name

# when to use which quotes
report = 'He said, "I will not go home"'

report.capitalize()

report.lower()

upped_report = report.upper()

# Accessing characters in strings
name[-1]


response = input(' Are you 18+ \n Enter n for no or y for yes:')