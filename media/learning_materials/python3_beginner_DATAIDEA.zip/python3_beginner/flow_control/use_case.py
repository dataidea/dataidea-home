import functions

summ = functions.add(5, 4)

print(summ)