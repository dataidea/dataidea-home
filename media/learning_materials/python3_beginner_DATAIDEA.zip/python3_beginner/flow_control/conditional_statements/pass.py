def my_function():
    pass

age = 19
if age > 18:
    pass
else:
    print('You are not allowed')