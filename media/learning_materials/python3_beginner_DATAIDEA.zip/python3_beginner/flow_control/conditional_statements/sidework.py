age = 15

if age > 18:
    if age > 50:
        print('You are too old')
    else: 
        print('Welcome!')
else:
    print('You are too young')
