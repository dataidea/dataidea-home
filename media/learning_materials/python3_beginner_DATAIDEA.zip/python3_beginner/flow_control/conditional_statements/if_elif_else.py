x = 10

if x > 10:
    print('x is more than 10')
elif x < 10:
    print('x is less than 10')
else:
    print('x is 10 because it\'s neither less than or more than 10')



# if else shorthand

print('x is less than 10') if x < 10 else print('x is not less than 10')