# For loops is used to loop through or iterate over a sequence or iterable objects

pets = ['cats', 'dogs', 'rabbits']

for pet in pets:
    print(pet)


# While loop
# This is used to execute a group of statements as long as the given expression is True

counter = 0

while counter < 5:
    print(counter)