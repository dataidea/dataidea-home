x = 5
y = 3
sum = x + y
print(sum)


a = 4; b = 3; sum = a + b; print(sum) 