# A program to add two numbers
x = 4 
y = 3

# some comment
# second comment
# third comment

print(x + y) # prints out the sum