print('''
Makerere University
P. O. Box 1234
Kampala, Uganda
30/11/2023
''')