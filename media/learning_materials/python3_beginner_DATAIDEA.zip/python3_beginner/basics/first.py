x = 4; y = 3; print(x + y)

