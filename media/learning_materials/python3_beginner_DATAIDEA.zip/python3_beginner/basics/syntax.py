# declaring variables
number1 = 1
number2 = 3

# print if condition is fulfilled some stuff that goes all the way
# some continuation of a comment
if number1 > number2:
    x = 'Hello, world'
    print(x)

