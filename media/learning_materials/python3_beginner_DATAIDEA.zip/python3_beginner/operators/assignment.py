# Assignment operators are used to assign values to variables.

# Name              Operation
# Assignment        x = y
# Addition Ass      x += y (x = x + y)
# Subtraction Ass   x -= y (x = x - y)
# Mult Ass          x *= y (x = x * y)
# Division Ass      x /= y (x = x / y)
# Expo Ass          x **= y (x = x ** y)
# Remainder Ass     x %= y (x = x % y)
# Floor Div Ass     x //= y (x = x // y)

# Examples
# Assignment
x = 10

# Addition Ass
x += 5 # x = x + 5 => x = 10 + 5 => x = 15

# Subraction Ass
x -= 5 # x = x - 5 => x = 10 - 5 => x = 5

# Multiplication Ass

