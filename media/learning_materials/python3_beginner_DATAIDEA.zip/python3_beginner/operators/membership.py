# Membership operators are used to check if a sequence
# is present in an object like a string, list etc

# Table of content
# Operator          Name
# in                The in operator
# not in            The not in operator

# Example
name = 'Tinye Robert'

print('Robert' not in name)
