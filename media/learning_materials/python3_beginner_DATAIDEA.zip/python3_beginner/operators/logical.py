# Table of content

# Operator          Description
# ------------------------------
# and               Logical and operator 
# or                Logical or  
# not               Logical not 

# Example
# Logical and
x = 4
expression = x > 3 and 8 < x
#               True and False => False

# Logical or
y = 7
expression_2 = 10 > y or 4 > y
#                   True or False => True

# Logical not
z = 8
expression_3 = not(10 == z)
#               not False => True


