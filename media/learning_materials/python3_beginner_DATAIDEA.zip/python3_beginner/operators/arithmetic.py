# Arithemators are symbols that perform operations on operands

# Arithmetic operators
# Operator  Description
# +          Addition
# -         Subraction
# /         Division
# *         Multiplication
# **        Exponentiates
# %         Remainder

# Addition
x = 10; y = 5; 
summation = x + y

# Subraction
difference = x - y

# Division
quotient = x / y

# Multiplication
product = x * y

# Exponentiation 
exponent = x ** y

# Remainder
remainder = x % y

# Floor Division
floor = 10 / 4


# Perform in a sequence
ans = 10 * 3 / 2 + 1
print(ans)




