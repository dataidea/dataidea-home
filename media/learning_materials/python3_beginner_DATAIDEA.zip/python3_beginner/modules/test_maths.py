from maths import arithmetics
from maths import functions

summation = arithmetics.add(number1=3, number2=7)

summation_square = functions.square(number=summation)

print(summation_square)
