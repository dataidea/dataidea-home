square = lambda number: number ** 2

cube = lambda number: number ** 2