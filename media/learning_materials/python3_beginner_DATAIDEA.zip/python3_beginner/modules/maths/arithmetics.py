add = lambda number1, number2: number1 + number2

subtract = lambda number1, number2: number1 - number2

multiply = lambda number1, number2: number1 * number2

divide = lambda number1, number2: number1 / number2