from our_classes.person import Person as psn

person1 = psn(
    first_name='John',
    last_name='Tong',
    age=14,
)

print(person1.first_name)
